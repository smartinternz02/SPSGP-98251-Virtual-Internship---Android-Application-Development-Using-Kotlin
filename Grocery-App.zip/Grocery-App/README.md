# Grocery_Android_App_Project_2
<h1>Virtual Internship - Android Application Development Using Kotlin
</h1>
<h2>
Build A Grocery Android App - Project 2
</h2>
<p>

<b>As we can't remember everything, users frequently forget to buy the things they want to buy. However, with the assistance of this app, you can make a list of the groceries you intend to buy so that you don't forget anything.</b>
  
</p>
<img width="960" alt="Screenshot 2022-09-13 114732" src="https://user-images.githubusercontent.com/83489094/189833225-3fac3e67-4bce-40aa-80a1-0d0b30e65b53.png">
<img width="960" alt="Screenshot 2022-09-13 114224" src="https://user-images.githubusercontent.com/83489094/189833241-46a4de49-ec8f-40b9-85e1-d426aa034756.png">



<h2><b><u>OUTPUT:</b></u></h2>

![photo_2022-09-13_13-51-51](https://user-images.githubusercontent.com/83489094/189850503-3d5f6c16-ad6a-4cc4-a965-eb0ef2e8f925.jpg)
![photo_2022-09-13_13-51-55](https://user-images.githubusercontent.com/83489094/189850535-c992481d-9cb0-4fd9-bfa7-97cc79a535d2.jpg)

# SmartInternz_Project_2
